from rango.models import *

print(DogSitter.objects.all())
